package com.quicknaira.app

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

// ---------- Helpers ----------

fun formatNaira(value: Long): String =
    "₦" + NumberFormat.getIntegerInstance(Locale.US).format(value)

fun formatDateFromNow(daysFromNow: Int): String {
    val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, daysFromNow) }
    return SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(cal.time)
}

fun greeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

/** Keeps status-bar icons readable on both the green login header and the light app canvas. */
@Composable
fun StatusBarIcons(darkIcons: Boolean, navDarkIcons: Boolean = darkIcons) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = darkIcons
            controller.isAppearanceLightNavigationBars = navDarkIcons
        }
    }
}

// ---------- Building blocks ----------

@Composable
fun QNCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    shape: Shape = RoundedCornerShape(20.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = CardDefaults.cardColors(containerColor = QN.Surface)
    val border = BorderStroke(1.dp, QN.Outline)
    if (onClick != null) {
        Card(onClick = onClick, modifier = modifier, shape = shape, colors = colors, border = border, content = content)
    } else {
        Card(modifier = modifier, shape = shape, colors = colors, border = border, content = content)
    }
}

@Composable
fun Brand(onDark: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).background(if (onDark) Color.White else QN.BrandGreen, RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("₦", color = if (onDark) QN.BrandGreen else Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("QuickNaira", color = if (onDark) Color.White else QN.Navy, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
            Text("Simple. Clear. Responsible.", color = if (onDark) QN.OnGreenSoft else QN.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String) {
    Column {
        Text(title, color = QN.Navy, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = QN.Muted, fontSize = 14.sp)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, color = QN.Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = modifier)
}

@Composable
fun InfoBanner(text: String, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().background(QN.Tint, RoundedCornerShape(14.dp)).padding(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(Icons.Outlined.Info, contentDescription = null, tint = QN.OnTint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, color = QN.Navy, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

@Composable
fun StatusChip(text: String, positive: Boolean) {
    Box(
        Modifier.background(if (positive) QN.Tint else QN.WarnBg, CircleShape)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text,
            color = if (positive) QN.OnTint else QN.WarnText,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun SummaryRow(label: String, value: String, emphasize: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = QN.Muted, fontSize = 14.sp)
        Text(
            value,
            color = QN.Navy,
            fontSize = 14.sp,
            fontWeight = if (emphasize) FontWeight.ExtraBold else FontWeight.SemiBold
        )
    }
}
