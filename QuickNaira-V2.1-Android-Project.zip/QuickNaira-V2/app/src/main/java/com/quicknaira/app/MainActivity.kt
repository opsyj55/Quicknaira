package com.quicknaira.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { QuickNairaV2() }
    }
}

enum class Tab(val label: String, val icon: ImageVector, val selectedIcon: ImageVector) {
    HOME("Home", Icons.Outlined.Home, Icons.Filled.Home),
    LOANS("Loans", Icons.Outlined.AccountBalanceWallet, Icons.Filled.AccountBalanceWallet),
    HISTORY("Activity", Icons.Outlined.History, Icons.Filled.History),
    PROFILE("Profile", Icons.Outlined.Person, Icons.Filled.Person)
}

@Composable
fun QuickNairaV2() {
    // rememberSaveable keeps the demo state across rotation / process recreation.
    var loggedIn by rememberSaveable { mutableStateOf(false) }
    var selected by rememberSaveable { mutableStateOf(Tab.HOME) }
    var customerName by rememberSaveable { mutableStateOf("QuickNaira User") }
    var amount by rememberSaveable { mutableStateOf("15000") }
    var duration by rememberSaveable { mutableIntStateOf(30) }

    var appAmount by rememberSaveable { mutableLongStateOf(0L) }
    var appDays by rememberSaveable { mutableIntStateOf(0) }
    var appSubmitted by rememberSaveable { mutableStateOf("") }
    var appDue by rememberSaveable { mutableStateOf("") }
    var assessmentDone by rememberSaveable { mutableStateOf(false) }

    val application = if (appAmount > 0L) {
        Application(appAmount, appDays, appSubmitted, appDue, assessmentDone)
    } else null

    // Appearance: 0 = follow system, 1 = light, 2 = dark (remembered between launches).
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("quicknaira", Context.MODE_PRIVATE) }
    var themeMode by rememberSaveable { mutableIntStateOf(prefs.getInt("theme_mode", 0)) }
    var onboarded by rememberSaveable { mutableStateOf(prefs.getBoolean("onboarded", false)) }
    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) { 1 -> false; 2 -> true; else -> systemDark }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val notify: (String) -> Unit = { msg ->
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(msg)
        }
    }

    QuickNairaTheme(darkTheme = dark) {
        if (!onboarded) {
            OnboardingScreen(onFinish = {
                onboarded = true
                prefs.edit().putBoolean("onboarded", true).apply()
            })
        } else if (!loggedIn) {
            WelcomeAndLogin(onContinue = { name ->
                customerName = name.ifBlank { "QuickNaira User" }
                loggedIn = true
                selected = Tab.HOME
            })
        } else {
            StatusBarIcons(darkIcons = !dark)
            BackHandler(enabled = selected != Tab.HOME) { selected = Tab.HOME }

            Scaffold(
                containerColor = QN.Canvas,
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    NavigationBar(containerColor = QN.Surface, tonalElevation = 8.dp) {
                        Tab.entries.forEach { tab ->
                            NavigationBarItem(
                                selected = selected == tab,
                                onClick = { selected = tab },
                                icon = {
                                    Icon(
                                        if (selected == tab) tab.selectedIcon else tab.icon,
                                        contentDescription = null
                                    )
                                },
                                label = { Text(tab.label) },
                                alwaysShowLabel = true,
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = QN.OnTint,
                                    selectedTextColor = QN.OnTint,
                                    unselectedIconColor = QN.Muted,
                                    unselectedTextColor = QN.Muted,
                                    indicatorColor = QN.Tint
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    Crossfade(targetState = selected, label = "tab") { tab ->
                        when (tab) {
                            Tab.HOME -> HomeTab(
                                name = customerName,
                                application = application,
                                onApply = { selected = Tab.LOANS },
                                onOpenActivity = { selected = Tab.HISTORY },
                                onOpenProfile = { selected = Tab.PROFILE }
                            )
                            Tab.LOANS -> LoansTab(
                                amount = amount,
                                onAmount = { amount = it },
                                duration = duration,
                                onDuration = { duration = it },
                                onSubmit = {
                                    appAmount = amount.toLongOrNull() ?: 0L
                                    appDays = duration
                                    appSubmitted = formatDateFromNow(0)
                                    appDue = formatDateFromNow(duration)
                                    assessmentDone = false
                                    selected = Tab.HISTORY
                                    notify("Demo application submitted")
                                }
                            )
                            Tab.HISTORY -> HistoryTab(
                                application = application,
                                onSimulate = {
                                    assessmentDone = true
                                    notify("Assessment step simulated – no money moved")
                                },
                                onReset = {
                                    appAmount = 0L
                                    assessmentDone = false
                                    notify("Demo application cleared")
                                },
                                onExplore = { selected = Tab.LOANS }
                            )
                            Tab.PROFILE -> ProfileTab(
                                name = customerName,
                                themeMode = themeMode,
                                onThemeMode = {
                                    themeMode = it
                                    prefs.edit().putInt("theme_mode", it).apply()
                                },
                                onSignOut = { loggedIn = false; selected = Tab.HOME },
                                onInfo = notify
                            )
                        }
                    }
                }
            }
        }
    }
}
