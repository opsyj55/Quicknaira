package com.quicknaira.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToLong

const val MIN_LOAN = 5_000L
const val MAX_LOAN = 50_000L
val PERIODS = listOf(7, 14, 30, 60, 90)

data class Application(
    val amount: Long,
    val days: Int,
    val submitted: String,
    val due: String,
    val assessmentDone: Boolean
)

// =====================================================================
// Welcome / Login
// =====================================================================

@Composable
fun WelcomeAndLogin(onContinue: (String) -> Unit) {
    StatusBarIcons(darkIcons = false, navDarkIcons = !QN.isDark)

    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var showPassword by rememberSaveable { mutableStateOf(false) }
    var attempted by rememberSaveable { mutableStateOf(false) }
    val focus = LocalFocusManager.current

    val nameOk = name.trim().length >= 2
    val phoneOk = phone.length == 11 && phone.startsWith("0")
    val passOk = password.length >= 4

    fun submit() {
        attempted = true
        if (nameOk && phoneOk && passOk) onContinue(name.trim())
    }

    Column(
        Modifier.fillMaxSize().background(QN.Canvas)
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding().imePadding()
    ) {
        // Brand header
        Column(
            Modifier.fillMaxWidth()
                .background(
                    Brush.verticalGradient(listOf(QN.DeepGreen, QN.BrandGreen)),
                    RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
                )
                .statusBarsPadding()
                .padding(start = 24.dp, end = 24.dp, top = 20.dp, bottom = 64.dp)
        ) {
            Brand(onDark = true)
            Spacer(Modifier.height(32.dp))
            Text(
                "Your finances,\nmade clearer.",
                fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.ExtraBold, color = Color.White
            )
            Spacer(Modifier.height(8.dp))
            Text("Explore the QuickNaira loan application experience.", color = QN.OnGreenSoft, fontSize = 15.sp)
        }

        // Form card overlaps the header
        Column(Modifier.padding(horizontal = 20.dp).offset(y = (-40).dp)) {
            QNCard(shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Get started", fontSize = 22.sp, color = QN.Navy, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))

                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("Full name") },
                        leadingIcon = { Icon(Icons.Outlined.Person, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        isError = attempted && !nameOk,
                        supportingText = { if (attempted && !nameOk) Text("Enter your full name") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) })
                    )
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(
                        value = phone, onValueChange = { phone = it.filter(Char::isDigit).take(11) },
                        label = { Text("Phone number") },
                        placeholder = { Text("08031234567") },
                        leadingIcon = { Icon(Icons.Outlined.Phone, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        isError = attempted && !phoneOk,
                        supportingText = {
                            Text(
                                if (attempted && !phoneOk) "Enter an 11-digit number starting with 0"
                                else "${phone.length}/11"
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) })
                    )
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(
                        value = password, onValueChange = { password = it },
                        label = { Text("Create a password") },
                        leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(
                                    if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = if (showPassword) "Hide password" else "Show password"
                                )
                            }
                        },
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        isError = attempted && !passOk,
                        supportingText = {
                            Text(
                                if (attempted && !passOk) "Use at least 4 characters"
                                else "At least 4 characters"
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { focus.clearFocus(); submit() })
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { focus.clearFocus(); submit() },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("Continue", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
        }
    }
}

// =====================================================================
// Home
// =====================================================================

@Composable
fun HomeTab(
    name: String,
    application: Application?,
    onApply: () -> Unit,
    onOpenActivity: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val first = name.substringBefore(" ").ifBlank { "there" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Brand()
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(QN.Tint),
                contentAlignment = Alignment.Center
            ) {
                Text(first.take(1).uppercase(), color = QN.OnTint, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("${greeting()}, $first 👋", color = QN.Navy, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Here is your QuickNaira overview.", color = QN.Muted, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))

        // Hero
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(QN.DeepGreen, QN.BrandGreen)))
                .padding(22.dp)
        ) {
            Text("Illustrative loan range", color = QN.OnGreenSoft, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text("₦5,000 – ₦50,000", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text("Not an approved offer or available credit limit.", color = QN.OnGreenSoft, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = onApply,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = QN.DeepGreen),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(48.dp)
            ) {
                Text("Explore loan options", fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickAction(Icons.Outlined.RequestQuote, "Apply", onApply, Modifier.weight(1f))
            QuickAction(Icons.Outlined.History, "Activity", onOpenActivity, Modifier.weight(1f))
            QuickAction(Icons.Outlined.Person, "Profile", onOpenProfile, Modifier.weight(1f))
        }

        Spacer(Modifier.height(22.dp))
        SectionTitle("Application overview")
        Spacer(Modifier.height(10.dp))
        if (application == null) {
            QNCard(Modifier.fillMaxWidth(), onClick = onApply) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Outlined.Description)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("No application yet", color = QN.Navy, fontWeight = FontWeight.SemiBold)
                        Text("Start a sample application to see how tracking works.", color = QN.Muted, fontSize = 13.sp)
                    }
                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = QN.Muted)
                }
            }
        } else {
            QNCard(Modifier.fillMaxWidth(), onClick = onOpenActivity) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(Icons.Outlined.Description)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Latest application", color = QN.Muted, fontSize = 13.sp)
                            Text(
                                "${formatNaira(application.amount)} • ${application.days} days",
                                color = QN.Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp
                            )
                        }
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = QN.Muted)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Total repayable ${formatNaira(Pricing.quote(application.amount, application.days).total)} by ${application.due}",
                        color = QN.Muted, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    StatusChip(
                        if (application.assessmentDone) "Submitted for review (demo)" else "Awaiting review (demo)",
                        positive = application.assessmentDone
                    )
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { if (application.assessmentDone) 0.66f else 0.33f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                        color = QN.Green, trackColor = QN.Tint
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MiniInfoCard("Repayment", "No active loan", Modifier.weight(1f))
            MiniInfoCard("Account", "Demo profile", Modifier.weight(1f))
        }
    }
}

@Composable
private fun IconBadge(icon: ImageVector) {
    Box(Modifier.size(44.dp).background(QN.Tint, CircleShape), contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = null, tint = QN.Green)
    }
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    QNCard(modifier, onClick = onClick, shape = RoundedCornerShape(18.dp)) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = QN.Green)
            Spacer(Modifier.height(6.dp))
            Text(label, color = QN.Navy, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun MiniInfoCard(title: String, value: String, modifier: Modifier = Modifier) {
    QNCard(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = QN.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, color = QN.Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

// =====================================================================
// Loans
// =====================================================================

@Composable
fun LoansTab(
    amount: String,
    onAmount: (String) -> Unit,
    duration: Int,
    onDuration: (Int) -> Unit,
    onSubmit: () -> Unit
) {
    val principal = amount.toLongOrNull() ?: 0L
    val valid = principal in MIN_LOAN..MAX_LOAN
    val dueDate = remember(duration) { formatDateFromNow(duration) }
    val quote = remember(principal, duration) { Pricing.quote(if (valid) principal else 0L, duration) }
    var confirm by rememberSaveable { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("Loan options", "Build and review a sample application.")
        Spacer(Modifier.height(18.dp))

        QNCard {
            Column(Modifier.padding(18.dp)) {
                Text("Requested amount", color = QN.Navy, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (valid) formatNaira(principal) else "—",
                    color = QN.Green, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.semantics { contentDescription = "Requested amount ${formatNaira(principal)}" }
                )
                Slider(
                    value = principal.coerceIn(MIN_LOAN, MAX_LOAN).toFloat(),
                    onValueChange = { onAmount(((it / 1000f).roundToLong() * 1000L).toString()) },
                    valueRange = MIN_LOAN.toFloat()..MAX_LOAN.toFloat(),
                    steps = 44
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatNaira(MIN_LOAN), color = QN.Muted, fontSize = 12.sp)
                    Text(formatNaira(MAX_LOAN), color = QN.Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5_000L, 10_000L, 20_000L, 30_000L, 50_000L).forEach { v ->
                        FilterChip(
                            selected = principal == v,
                            onClick = { onAmount(v.toString()) },
                            label = { Text(formatNaira(v)) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = QN.Tint, selectedLabelColor = QN.OnTint
                            )
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = amount,
                    onValueChange = { onAmount(it.filter(Char::isDigit).take(7)) },
                    label = { Text("Or enter an exact amount") },
                    modifier = Modifier.fillMaxWidth(),
                    prefix = { Text("₦ ") },
                    singleLine = true,
                    isError = !valid,
                    supportingText = {
                        Text(if (valid) "Between ${formatNaira(MIN_LOAN)} and ${formatNaira(MAX_LOAN)}" else "Enter an amount from ${formatNaira(MIN_LOAN)} to ${formatNaira(MAX_LOAN)}")
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done)
                )

                Spacer(Modifier.height(14.dp))
                Text("Repayment period (days)", color = QN.Navy, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    PERIODS.forEach { days ->
                        FilterChip(
                            selected = duration == days,
                            onClick = { onDuration(days) },
                            label = { Text("$days", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = QN.Tint, selectedLabelColor = QN.OnTint
                            )
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        QNCard {
            Column(Modifier.padding(18.dp)) {
                Text("Cost breakdown", color = QN.Navy, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                SummaryRow("You receive", if (valid) formatNaira(quote.principal) else "—")
                SummaryRow("Interest (${Pricing.dailyRateLabel()})", if (valid) formatNaira(quote.interest) else "—")
                SummaryRow("Processing fee (${Pricing.feeLabel()})", if (valid) formatNaira(quote.fee) else "—")
                Spacer(Modifier.height(6.dp))
                HorizontalDivider(color = QN.Outline)
                Spacer(Modifier.height(6.dp))
                SummaryRow("Total repayable", if (valid) formatNaira(quote.total) else "—", emphasize = true)
                SummaryRow("Repayment period", "$duration days")
                SummaryRow("Due date", dueDate)
                SummaryRow("Effective annual rate (APR)", if (valid) Pricing.aprLabel(quote) else "—")
                Spacer(Modifier.height(8.dp))
                Text(
                    "Total repayable = amount + interest + processing fee. Nothing is deducted from the amount you receive.",
                    color = QN.Muted, fontSize = 12.sp
                )
            }
        }

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { confirm = true },
            enabled = valid,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) { Text("Review & submit demo application", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = QN.Surface,
            title = { Text("Submit demo application?") },
            text = {
                Text(
                    "${formatNaira(principal)} for $duration days.\n\nTotal repayable: ${formatNaira(quote.total)}\n(includes ${formatNaira(quote.interest)} interest and ${formatNaira(quote.fee)} fee)\nDue: $dueDate"
                )
            },
            confirmButton = {
                TextButton(onClick = { confirm = false; onSubmit() }) { Text("Submit") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}

// =====================================================================
// History / Activity
// =====================================================================

@Composable
fun HistoryTab(
    application: Application?,
    onSimulate: () -> Unit,
    onReset: () -> Unit,
    onExplore: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("Activity", "Your demo application and payment activity.")
        Spacer(Modifier.height(18.dp))

        if (application == null) {
            QNCard(Modifier.fillMaxWidth()) {
                Column(
                    Modifier.fillMaxWidth().padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(64.dp).background(QN.Tint, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.History, contentDescription = null, tint = QN.Green, modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("No activity yet", color = QN.Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Submit a sample application and you'll be able to follow its progress here.",
                        color = QN.Muted, fontSize = 14.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = onExplore, shape = RoundedCornerShape(14.dp), modifier = Modifier.height(48.dp)) {
                        Text("Explore loan options")
                    }
                }
            }
            return@Column
        }

        // Summary
        QNCard {
            Column(Modifier.padding(18.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Loan application", color = QN.Muted, fontSize = 13.sp)
                        Text(formatNaira(application.amount), color = QN.Navy, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    StatusChip(
                        if (application.assessmentDone) "Submitted" else "Awaiting review",
                        positive = application.assessmentDone
                    )
                }
                Spacer(Modifier.height(10.dp))
                HorizontalDivider(color = QN.Outline)
                Spacer(Modifier.height(6.dp))
                SummaryRow("Repayment period", "${application.days} days")
                SummaryRow("Submitted", application.submitted)
                val q = Pricing.quote(application.amount, application.days)
                SummaryRow("Interest", formatNaira(q.interest))
                SummaryRow("Processing fee", formatNaira(q.fee))
                SummaryRow("Total repayable", formatNaira(q.total), emphasize = true)
                SummaryRow("Due date", application.due)
            }
        }

        // Progress timeline
        Spacer(Modifier.height(14.dp))
        QNCard {
            Column(Modifier.padding(18.dp)) {
                Text("Progress", color = QN.Navy, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                TimelineStep("Application submitted", application.submitted, StepState.DONE, isLast = false)
                TimelineStep(
                    "Assessment step",
                    if (application.assessmentDone) "Simulation completed" else "Action needed – complete the demo step below",
                    if (application.assessmentDone) StepState.DONE else StepState.CURRENT,
                    isLast = false
                )
                TimelineStep("Credit decision", "Not available in this demo", StepState.PENDING, isLast = true)
            }
        }

        // Assessment step
        Spacer(Modifier.height(14.dp))
        QNCard {
            Column(Modifier.padding(18.dp)) {
                Text("Assessment step", color = QN.Navy, fontWeight = FontWeight.Bold)
                Text(
                    if (application.assessmentDone) "Simulation completed" else "Not completed",
                    color = if (application.assessmentDone) QN.Green else QN.Muted,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "₦500 shown for prototype testing only. This button does not charge a card or transfer money.",
                    color = QN.Muted, fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onSimulate,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    enabled = !application.assessmentDone
                ) {
                    Text(if (application.assessmentDone) "Demo step completed" else "Simulate assessment step")
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onReset, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("Clear demo application", color = QN.Muted)
        }
    }
}

enum class StepState { DONE, CURRENT, PENDING }

@Composable
private fun TimelineStep(title: String, subtitle: String, state: StepState, isLast: Boolean) {
    val lineColor = if (state == StepState.DONE) QN.Green else QN.Outline
    Row(Modifier.height(IntrinsicSize.Min)) {
        Column(Modifier.width(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            when (state) {
                StepState.DONE -> Box(Modifier.size(24.dp).background(QN.Green, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Check, contentDescription = "Done", tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(15.dp))
                }
                StepState.CURRENT -> Box(Modifier.size(24.dp).border(3.dp, QN.Green, CircleShape).background(QN.Surface, CircleShape))
                StepState.PENDING -> Box(Modifier.size(24.dp).border(2.dp, QN.Outline, CircleShape))
            }
            if (!isLast) Box(Modifier.width(2.dp).weight(1f).background(lineColor))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.padding(bottom = if (isLast) 0.dp else 18.dp)) {
            Text(
                title,
                color = if (state == StepState.PENDING) QN.Muted else QN.Navy,
                fontWeight = FontWeight.SemiBold, fontSize = 15.sp
            )
            Text(subtitle, color = QN.Muted, fontSize = 13.sp)
        }
    }
}

// =====================================================================
// Profile
// =====================================================================

@Composable
fun ProfileTab(
    name: String,
    themeMode: Int,
    onThemeMode: (Int) -> Unit,
    onSignOut: () -> Unit,
    onInfo: (String) -> Unit
) {
    var notifications by rememberSaveable { mutableStateOf(true) }
    var confirmSignOut by rememberSaveable { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("My profile", "Manage your demo account.")
        Spacer(Modifier.height(20.dp))
        QNCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).background(QN.Tint, CircleShape), contentAlignment = Alignment.Center) {
                    Text(name.take(1).uppercase(), color = QN.OnTint, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(name, color = QN.Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Demo customer profile", color = QN.Muted, fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Text("ACCOUNT", color = QN.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        ProfileRow(Icons.Outlined.VerifiedUser, "Identity verification", "Not connected in demo") {
            onInfo("Identity verification isn't available in this demo.")
        }
        ProfileRow(Icons.Outlined.AccountBalance, "Bank account", "Not added") {
            onInfo("Bank accounts can't be added in this demo.")
        }

        Spacer(Modifier.height(18.dp))
        Text("PREFERENCES", color = QN.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        ProfileRow(
            Icons.Outlined.DarkMode, "Appearance",
            when (themeMode) { 1 -> "Light"; 2 -> "Dark"; else -> "System default" }
        ) { onThemeMode((themeMode + 1) % 3) }
        ProfileRow(
            Icons.Outlined.Notifications, "Notifications",
            if (notifications) "On (demo only)" else "Off (demo only)",
            onClick = { notifications = !notifications },
            trailing = { Switch(checked = notifications, onCheckedChange = { notifications = it }) }
        )
        ProfileRow(Icons.Outlined.SupportAgent, "Help and support", "Support centre placeholder") {
            onInfo("The support centre is a placeholder in this demo.")
        }

        Spacer(Modifier.height(24.dp))
        OutlinedButton(
            onClick = { confirmSignOut = true },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Sign out")
        }
    }

    if (confirmSignOut) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            containerColor = QN.Surface,
            title = { Text("Sign out?") },
            text = { Text("Your demo session will end.") },
            confirmButton = { TextButton(onClick = { confirmSignOut = false; onSignOut() }) { Text("Sign out") } },
            dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ProfileRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    trailing: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    QNCard(Modifier.fillMaxWidth().padding(top = 9.dp), onClick = onClick, shape = RoundedCornerShape(15.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = QN.Green)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = QN.Navy, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = QN.Muted, fontSize = 13.sp)
            }
            if (trailing != null) trailing() else Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = QN.Muted)
        }
    }
}
