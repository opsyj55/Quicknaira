package com.quicknaira.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
class QNColors(
    val isDark: Boolean,
    val green: Color,
    val onTint: Color,
    val text: Color,
    val canvas: Color,
    val surface: Color,
    val muted: Color,
    val tint: Color,
    val outline: Color,
    val error: Color,
    val warnBg: Color,
    val warnText: Color
)

private val LightQN = QNColors(
    isDark = false,
    green = Color(0xFF07845B), onTint = Color(0xFF056344),
    text = Color(0xFF102A43), canvas = Color(0xFFF4F7F5), surface = Color.White,
    muted = Color(0xFF5B6B7C), tint = Color(0xFFE3F4EC), outline = Color(0xFFDCE5E0),
    error = Color(0xFFB3261E), warnBg = Color(0xFFFFF4D6), warnText = Color(0xFF8A5A00)
)

private val DarkQN = QNColors(
    isDark = true,
    green = Color(0xFF3DBE8B), onTint = Color(0xFF8FE3BD),
    text = Color(0xFFE6EEE9), canvas = Color(0xFF0E1512), surface = Color(0xFF16201B),
    muted = Color(0xFF9AAAA2), tint = Color(0xFF17382B), outline = Color(0xFF2A3A33),
    error = Color(0xFFF2B8B5), warnBg = Color(0xFF3A2E10), warnText = Color(0xFFF5C969)
)

private val LocalQN = staticCompositionLocalOf { LightQN }

/** Theme-aware palette. Use QN.X inside composables; the constants never change with the theme. */
object QN {
    // Constants (same in light and dark): brand gradient, logo, text on the gradient.
    val BrandGreen = Color(0xFF07845B)
    val DeepGreen = Color(0xFF056344)
    val OnGreenSoft = Color(0xFFD3EDE2)

    val isDark: Boolean @Composable @ReadOnlyComposable get() = LocalQN.current.isDark
    val Green: Color @Composable @ReadOnlyComposable get() = LocalQN.current.green
    val OnTint: Color @Composable @ReadOnlyComposable get() = LocalQN.current.onTint
    val Navy: Color @Composable @ReadOnlyComposable get() = LocalQN.current.text
    val Canvas: Color @Composable @ReadOnlyComposable get() = LocalQN.current.canvas
    val Surface: Color @Composable @ReadOnlyComposable get() = LocalQN.current.surface
    val Muted: Color @Composable @ReadOnlyComposable get() = LocalQN.current.muted
    val Tint: Color @Composable @ReadOnlyComposable get() = LocalQN.current.tint
    val Outline: Color @Composable @ReadOnlyComposable get() = LocalQN.current.outline
    val Error: Color @Composable @ReadOnlyComposable get() = LocalQN.current.error
    val WarnBg: Color @Composable @ReadOnlyComposable get() = LocalQN.current.warnBg
    val WarnText: Color @Composable @ReadOnlyComposable get() = LocalQN.current.warnText
}

@Composable
fun QuickNairaTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    val q = if (darkTheme) DarkQN else LightQN
    val scheme = if (darkTheme) {
        darkColorScheme(
            primary = q.green, onPrimary = Color(0xFF00281A),
            primaryContainer = q.tint, onPrimaryContainer = q.onTint,
            secondary = q.onTint, background = q.canvas, onBackground = q.text,
            surface = q.surface, onSurface = q.text, onSurfaceVariant = q.muted,
            surfaceVariant = q.tint, outline = q.muted, outlineVariant = q.outline,
            error = q.error
        )
    } else {
        lightColorScheme(
            primary = q.green, onPrimary = Color.White,
            primaryContainer = q.tint, onPrimaryContainer = q.onTint,
            secondary = q.text, background = q.canvas, onBackground = q.text,
            surface = q.surface, onSurface = q.text, onSurfaceVariant = q.muted,
            surfaceVariant = q.tint, outline = q.muted, outlineVariant = q.outline,
            error = q.error
        )
    }
    CompositionLocalProvider(LocalQN provides q) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
