package com.quicknaira.app

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.RequestQuote
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private data class OnboardingPage(val icon: ImageVector, val title: String, val body: String)

private val onboardingPages = listOf(
    OnboardingPage(
        Icons.Outlined.RequestQuote,
        "Choose what you need",
        "Pick an amount and a repayment period that fits you. Adjust with the slider or type an exact figure."
    ),
    OnboardingPage(
        Icons.Outlined.ReceiptLong,
        "See the full cost first",
        "Interest, fees and the total you'll repay are shown before you submit, with no surprises later."
    ),
    OnboardingPage(
        Icons.Outlined.Timeline,
        "Follow every step",
        "Track your application from submission to decision in one clear timeline."
    )
)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    StatusBarIcons(darkIcons = !QN.isDark)

    val pagerState = rememberPagerState(pageCount = { onboardingPages.size })
    val scope = rememberCoroutineScope()
    val current = pagerState.currentPage
    val last = current == onboardingPages.lastIndex

    Column(
        Modifier.fillMaxSize().background(QN.Canvas)
            .statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Brand()
            if (!last) TextButton(onClick = onFinish) { Text("Skip", color = QN.Muted) }
        }

        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f).fillMaxWidth()) { index ->
            val page = onboardingPages[index]
            Column(
                Modifier.fillMaxSize().padding(horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(Modifier.size(168.dp).background(QN.Tint, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(page.icon, contentDescription = null, tint = QN.Green, modifier = Modifier.size(76.dp))
                }
                Spacer(Modifier.height(36.dp))
                Text(page.title, color = QN.Navy, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(page.body, color = QN.Muted, fontSize = 16.sp, lineHeight = 23.sp, textAlign = TextAlign.Center)
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 20.dp)
                .semantics { contentDescription = "Page ${current + 1} of ${onboardingPages.size}" },
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            onboardingPages.indices.forEach { i ->
                val width by animateDpAsState(if (i == current) 28.dp else 8.dp, label = "dot")
                Box(
                    Modifier.padding(horizontal = 4.dp).height(8.dp).width(width).clip(CircleShape)
                        .background(if (i == current) QN.Green else QN.Outline)
                )
            }
        }

        Button(
            onClick = {
                if (last) onFinish() else scope.launch { pagerState.animateScrollToPage(current + 1) }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) { Text(if (last) "Get started" else "Next", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
    }
}
