package com.quicknaira.app

import java.util.Locale
import kotlin.math.roundToLong

/**
 * Loan pricing. >>> The two rates below are PLACEHOLDERS. Replace them with your real, approved
 * terms (and make sure they match your lender licence / regulator disclosure rules) before launch. <<<
 *
 * Total repayable = principal + interest + processing fee. Nothing is deducted from the amount
 * the customer receives, so what is shown on screen is exactly what is charged.
 */
object Pricing {
    const val DAILY_INTEREST_PERCENT = 0.15   // % of principal per day
    const val PROCESSING_FEE_PERCENT = 1.0    // % of principal, charged once

    data class Quote(val principal: Long, val days: Int, val interest: Long, val fee: Long) {
        val total: Long get() = principal + interest + fee

        /** Effective annual rate of interest + fee, so loans of different lengths can be compared. */
        val apr: Double
            get() = if (principal <= 0L || days <= 0) 0.0
            else (interest + fee).toDouble() / principal * (365.0 / days) * 100.0
    }

    fun quote(principal: Long, days: Int): Quote {
        if (principal <= 0L) return Quote(0L, days, 0L, 0L)
        val interest = (principal * DAILY_INTEREST_PERCENT / 100.0 * days).roundToLong()
        val fee = (principal * PROCESSING_FEE_PERCENT / 100.0).roundToLong()
        return Quote(principal, days, interest, fee)
    }

    fun dailyRateLabel(): String = String.format(Locale.US, "%.2f%% a day", DAILY_INTEREST_PERCENT)
    fun feeLabel(): String = String.format(Locale.US, "%.1f%% one-off", PROCESSING_FEE_PERCENT)
    fun aprLabel(q: Quote): String = String.format(Locale.US, "%,.0f%%", q.apr)
}
